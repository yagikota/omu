// 1201201140
// 八木洸太

double plus(double x, double y);

double minus(double x, double y);

double multiply(double x, double y);

double divide(double x, double y);
