// 1201201140
// 八木洸太

#include <stdio.h>
#include "kadai8-1201201140-1.h"

double plus(double x, double y) {
	return x + y;
}

double minus(double x, double y) {
	return x - y;
}

double multiply(double x, double y) {
	return x * y;
}

double divide(double x, double y) {
	return x / y;
}
